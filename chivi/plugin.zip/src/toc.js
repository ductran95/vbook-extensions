function execute(url) {
  var urlData = JSON.parse(url);

  var json = Http.get(urlData.url).string();

  var data = JSON.parse(json);

  var chapList = [];

  if (data && data.chaps) {
    chapList = data.chaps.map((item) => {
      return {
        name: "/~" + urlData.book + "/~" + item.uslug,
        url: "/~" + urlData.book + "/~" + item.uslug,
        host: "https://chivi.xyz",
      };
    });
  }

  return Response.success(chapList);
}
