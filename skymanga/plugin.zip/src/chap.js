function execute(url) {
    var doc = Http.get(url).html();
    

    var data = ['https://skymanga.co/wp-content/uploads/WP-manga/data/manga_5f47ed8a91b56/1c2d69c82e24514bd82915435257d072/1.jpg'];
    

    return Response.success(data);
}