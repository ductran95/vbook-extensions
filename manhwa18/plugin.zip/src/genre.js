function execute() {
    return Response.success([
        {title: "Action", input: "https://manhwa18.com/manga-list-genre-action.html", script: "gen.js"},
        {title: "18+", input: "https://manhwa18.com/manga-list-genre-18.html", script: "gen.js"},
        {title: "Adult", input: "https://manhwa18.com/manga-list-genre-adult.html", script: "gen.js"},
        {title: "Anime", input: "https://manhwa18.com/manga-list-genre-anime.html", script: "gen.js"},
        {title: "Comedy", input: "https://manhwa18.com/manga-list-genre-comedy.html", script: "gen.js"},
        {title: "Comic", input: "https://manhwa18.com/manga-list-genre-comic.html", script: "gen.js"},
        {title: "Doujinshi", input: "https://manhwa18.com/manga-list-genre-doujinshi.html", script: "gen.js"},
        {title: "Drama", input: "https://manhwa18.com/manga-list-genre-drama.html", script: "gen.js"},
        {title: "Ecchi", input: "https://manhwa18.com/manga-list-genre-ecchi.html", script: "gen.js"},
        {title: "Fantasy", input: "https://manhwa18.com/manga-list-genre-fantasy.html", script: "gen.js"},
        {title: "Gender Bender", input: "https://manhwa18.com/manga-list-genre-gender bender.html", script: "gen.js"},
        {title: "Harem", input: "https://manhwa18.com/manga-list-genre-harem.html", script: "gen.js"},
        {title: "Historical", input: "https://manhwa18.com/manga-list-genre-historical.html", script: "gen.js"},
        {title: "Horror", input: "https://manhwa18.com/manga-list-genre-horror.html", script: "gen.js"},
        {title: "Josei", input: "https://manhwa18.com/manga-list-genre-josei.html", script: "gen.js"},
        {title: "Live action", input: "https://manhwa18.com/manga-list-genre-live action.html", script: "gen.js"},
        {title: "Manhua", input: "https://manhwa18.com/manga-list-genre-manhua.html", script: "gen.js"},
        {title: "Manhwa", input: "https://manhwa18.com/manga-list-genre-manhwa.html", script: "gen.js"},
        {title: "Martial Art", input: "https://manhwa18.com/manga-list-genre-martial art.html", script: "gen.js"},
        {title: "Mature", input: "https://manhwa18.com/manga-list-genre-mature.html", script: "gen.js"}
    ]);
}